// Task status enum
enum TaskStatus {
    Pending = "PENDING",
    Completed = "COMPLETED"
}

// Task class
class Task {
    name: string;
    dueDate: string;
    status: TaskStatus;

    constructor(name: string, dueDate: string) {
        this.name = name;
        this.dueDate = dueDate;
        this.status = TaskStatus.Pending;
    }

    markCompleted(): void {
        this.status = TaskStatus.Completed;
    }
}

// Task list
let tasks: Task[] = [];

// ADD TASK (IMPORTANT FUNCTION)
function addTask(): void {
    const taskInput = document.getElementById("taskInput") as HTMLInputElement;
    const dateInput = document.getElementById("dateInput") as HTMLInputElement;

    const taskName = taskInput.value;
    const taskDate = dateInput.value;

    if (taskName === "" || taskDate === "") {
        alert("Please enter task and date");
        return;
    }

    const task = new Task(taskName, taskDate);
    tasks.push(task);

    taskInput.value = "";
    dateInput.value = "";

    renderTasks(tasks);
}

// COMPLETE TASK
function completeTask(index: number): void {
    tasks[index].markCompleted();
    renderTasks(tasks);
}

// SHOW ALL
function showAll(): void {
    renderTasks(tasks);
}

// SHOW COMPLETED
function showCompleted(): void {
    renderTasks(tasks.filter(t => t.status === TaskStatus.Completed));
}

// SHOW PENDING
function showPending(): void {
    renderTasks(tasks.filter(t => t.status === TaskStatus.Pending));
}

// DISPLAY TASKS ON SCREEN
function renderTasks(taskArray: Task[]): void {
    const list = document.getElementById("taskList") as HTMLUListElement;
    list.innerHTML = "";

    taskArray.forEach((task, index) => {
        const li = document.createElement("li");
        li.textContent = `${task.name} (${task.dueDate})`;

        if (task.status === TaskStatus.Completed) {
            li.classList.add("completed");
        }

        li.onclick = () => completeTask(index);
        list.appendChild(li);
    });
}
