// Interface for successful response
interface WeatherData {
    name: string;
    main: {
        temp: number;
        humidity: number;
    };
    weather: {
        description: string;
    }[];
}

// Interface for error response
interface ErrorResponse {
    message: string;
}

// Union Type
type ApiResponse = WeatherData | ErrorResponse;

// DOM elements
const cityInput = document.getElementById("cityInput") as HTMLInputElement;
const button = document.getElementById("getWeatherBtn") as HTMLButtonElement;
const resultDiv = document.getElementById("result") as HTMLDivElement;

// ✅ REAL API KEY
const API_KEY = "c3f28138da23d9f92bb89a5f5ba3df2c";

// Event handling
button.addEventListener("click", () => {
    const city = cityInput.value.trim();

    if (city === "") {
        resultDiv.innerHTML = "❌ Please enter a city name";
        return;
    }

    getWeather(city);
});

// Fetch weather data
async function getWeather(city: string): Promise<void> {
    try {
        const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
        );

        const data: ApiResponse = await response.json();

        if (!response.ok) {
            const errorData = data as ErrorResponse;
            resultDiv.innerHTML = `❌ ${errorData.message}`;
            return;
        }

        displayWeather(data as WeatherData);

    } catch {
        resultDiv.innerHTML = "❌ Network error. Please try again.";
    }
}

// Display weather data (NO Kelvin conversion ❌)
function displayWeather(data: WeatherData): void {
    resultDiv.innerHTML = `
        <h3>📍 ${data.name}</h3>
        <p>🌡 Temperature: ${data.main.temp} °C</p>
        <p>💧 Humidity: ${data.main.humidity}%</p>
        <p>☁ Condition: ${data.weather[0].description}</p>
    `;
}
